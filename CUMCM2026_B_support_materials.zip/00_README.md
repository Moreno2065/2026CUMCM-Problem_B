# CUMCM2026 B 题支撑材料包 · 目录说明

本包为 CUMCM2026 B 题（“干扰源定位与清除”）参赛论文《B题论文_v0.4.docx》的支撑材料。
打包目标：单包体积 ≤ 20 MB、正式测试日志以**原名**入包且文件名不做任何修改、顶层目录与论文附录表1 一一对应。

## 顶层目录

| 目录 | 内容 |
| --- | --- |
| `00_README.md` | 本文件 |
| `01_source_code/` | 四个部分的完整可运行源程序，统一置于 `src/` 下：`src/q1/code/`、`src/q2/{code,formal,tests_formal}/`、`src/q3+4/`（V1 引擎）、`src/q3+q4_v2/`（最终求解栈） |
| `02_documentation/` | 模型与实现文档：`q3+q4_v2_docs/`、`q3+4_docs/`、`q2_reports/`、`q2_model_docs/` |
| `03_paper_evidence/` | 论文证据：`tables/`（汇总表 csv）、`cases/`（案例与种子）、`figures/`（**12 个文件**：正文三张流程图 `fig04_q1_flow.png`、`fig05_q3_flow.png`、`fig06_q4_flow.png`，论文图 `fig07_v1_baseline.jpg`、`fig08_framework.jpg`、`fig09_paired_performance.jpg`、`fig10_q3_ablation.jpg`、`fig11_q4_ablation.jpg`、`fig12_sensitivity.jpg`、`fig13_time_breakdown.jpg`、`fig14_q3_route.jpg`、`fig15_q4_route.jpg`（清单见 `figures_manifest.json` 与 `flowcharts_manifest.json`））、`figure_data/`（绘图数据）、顶层 json/md（claims、figures_manifest、variant_registry、source_manifest 等） |
| `04_raw_run_evidence/` | 主实验原始运行证据：`per_run/<策略>/<问题>/<run>__{metrics,run_report,verifier_report}.json`（v1_frozen 与 v2_final 全部 run 的标量）与 `sample_runs/`（每策略每问一个完整 run） |
| `05_simulator_logs/` | 模拟器导出的 **6 份正式测试行为日志** `.jlog` 及同名 `.result.json`：**文件名与原件逐字符相同**；信封内的 `team_no` 已按「脱敏说明」就地等长替换 |
| `06_formal_test_outputs/` | 三次正式测试的程序侧运行产物：`realq3/{1,2,3}/`、`realq4/{1,2,3}/`，每目录 10 个文件（metrics、run_report、verifier_report、actions.csv、api_log.jsonl、client_api_log.jsonl、client_rows.jsonl、policy_config.json、engine_result.json、solver_result.json） |
| 包根 | 无日志副本：6 组正式日志只放在 `05_simulator_logs/` 一处，避免出现两份同名文件 |

## 正式测试日志（05_simulator_logs/）

| 日志文件（原名） | 字节（与原件相同） | SHA-256（脱敏后） | 外层 `team_no` 区间 | 加密载荷区间 | 票据内被替换字段（值区间） |
| --- | ---: | --- | --- | --- | --- |
| `formal-p3-1-VUXH-728S-5QND-4JGQ.jlog` | 101576 | `46f357f57ccdee2ff9b5602702102c1a3083ea117b5de4026d1ccb77f4050845` | [131, 143] | `[3230, 101576)`，98346 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |
| `formal-p3-2-F8H9-H7J2-ECJU-88BU.jlog` | 104944 | `688dbb85c2ab68d591df618281bf25de480bdad90d08de2a80d5d12a3b00f46f` | [131, 143] | `[3230, 104944)`，101714 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |
| `formal-p3-3-G8NN-UDNJ-6QEF-F9GC.jlog` | 115517 | `0de681fcdb2cd16b35f5d957fcb36a0928fa6e96e1e023e30638c95e1b8952cb` | [131, 143] | `[3230, 115517)`，112287 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |
| `formal-p4-1-PFZQ-G9BM-KDEX-ZQN9.jlog` | 127269 | `397bb41d3d6df5f1e14841ca62d396a35b1360e62acda4980380cfd8f636c5f0` | [131, 143] | `[3230, 127269)`，124039 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |
| `formal-p4-2-S7M2-ASX9-NJGA-NWDX.jlog` | 115271 | `35a2950d05dff7a56d20b08cab5916bb97362a3815c2d486aef3eefe53ce7146` | [131, 143] | `[3230, 115271)`，112041 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |
| `formal-p4-3-VVQE-DSM4-V5XN-TFGF.jlog` | 132329 | `f32317ed1fe3e1bb30bbec5988ba16c77514274df9572a627c4dce27f36fb62b` | [131, 143] | `[3230, 132329)`，129099 B | `team_no` 12 B [569, 589]、`sealed_case_package_sha256` 64 B [717, 805]、`device_digest` 64 B [825, 913]、`case_unlock_envelope_sha256` 64 B [1273, 1361] |


6 份 `.result.json` 为模拟器随日志导出的信封；其 `package_sha256` 记录的是模拟器对**原始导出文件**的封条，与本表脱敏后 SHA-256 不同，属主动脱敏的预期结果（见下文「脱敏说明」）。

## 脱敏（de-identification）

| 范围 | 处理 |
| --- | --- |
| **我方文件**（源码、运行产物、`03_paper_evidence/` 下的 json/csv 等） | 12 位参赛队号（为隐私不在此复现）→ 占位符（实测 1,201 处 / 37 文件）；`"robot_id"` 的真实数值 → 占位符（实测 1,283 处 / 142 文件，包内已无真实 robot_id 值）；`team_no/team_id/participant_id/robot_id = <数字>` → `<id>`（实测剩余 0 处）；绝对路径与用户目录 → `<project-root>` / `<workspace>` / `<package-root>` |
| **官方模拟器导出**：`05_simulator_logs/*.jlog` 与同名 `*.result.json` | **已就地等长替换**：两类文件的 `team_no` 值均替换为占位值（12 → 12 字节）；日志的**文件名、文件字节数与加密行为载荷均未改动**；字段区间与载荷区间见上表，方法见「脱敏说明（重要）」。因此包内 12 个日志/信封文件的 `team_no` 全部是占位值，真实队号明文在包内 0 命中 |

## 复现方式

**重要**：Q1/Q2 源程序使用绝对导入（如 `from src.q2.code.geometry.primitives import Point2`、
`from src.q1.code.q1_geometry import ...`），因此 `01_source_code/` 必须作为导入根目录（cwd），
`src/` 目录名不可改动。

```powershell
cd 01_source_code
# 问题一
python -X utf8 src/q1/code/q1_cli.py --input src/q1/code/example_input.json
# 问题二（形式化最优性证书回放）
python -X utf8 src/q2/formal/proof_loop.py
# 问题三 / 问题四（最终求解栈）
python -X utf8 src/q3+q4_v2/absorbed/run_absorbed.py --mode q3 --engine q3-v5 `
    --sim http-synthetic --seed 101 --n-sources 10 --scenario random --output-dir runs/absorbed_q3_smoke
```

## 体积与裁剪

为满足 20 MB 上限，本包剔除了以下几类**可由源程序再生成或已由汇总替代**的内容：`code/results/`、
`code/output/` 运行结果树，`paper_evidence/{runs,ablation,tuning}` 原始实验树，`_legacy_superseded_v6`
被取代副本，未引用的冒烟运行目录 `runs/official_*`、`runs/oldq4sim`，以及 `__pycache__`/`.pytest_cache`
构建缓存。四部分源程序的可运行入口与其 import 依赖均完整保留；论文所用的汇总证据已按
`03_paper_evidence/` 收进本包，阅读本包无需查阅包外文件。

## 脱敏说明（重要）

按竞赛要求隐去参赛队号：6 份官方导出的行为日志（`.jlog`）中，外层信封字段 `team_no` 的值，以及票据
`server_ticket_b64` 内层 JSON 中的 `team_no`、`device_digest`、`sealed_case_package_sha256`、
`case_unlock_envelope_sha256` 四个字段，均已就地替换为与原值**等长**的占位值；全程为**纯字节级操作**，
未经任何文本解码/编码往返。日志的**文件名**、**文件字节数**与**加密行为载荷**均未改动（载荷区与原件
逐字节相同）；票据的**声明长度字段与实际 JSON 跨度一致**，**签名区 64 字节与原文件逐字节相同**。
需说明的是：该签名所覆盖的内容已发生变化，因此其**密码学校验不再通过**——这是**主动脱敏**的结果，
而非文件损坏。需要核对原始封条时，请以模拟器上传队列中的原件为准（同名 `.result.json` 中的
`package_sha256` 即为对原始导出文件的封条）。

### 自证清单（可逐条复核）

| # | 判据 | 结果 |
| --- | --- | --- |
| ① | 6 份 `.jlog` 与原名原件 **size delta** | **0**（101576 / 104944 / 115517 / 127269 / 115271 / 132329 全等） |
| ② | 差异字节区间 | **只落在** `team_no` 值区间 `[131,143)` 与票据 `server_ticket_b64` 值区间内（内层四个字段，逐份区间见上表）；其余字节逐一相同 |
| ③ | **加密行为载荷区**（信封头之后的密文分帧区，起点 offset 3230，长度见下表） | **逐字节相同** |
| ④ | **票据 `u32@10`**（内层 JSON 声明长度）**== 实际 JSON 跨度** | **932 == 932**，自洽 |
| ⑤ | 外层信封：`JMBFLOG1` 文件头 + 其长度字段（u32=3216）与头部 JSON 字节跨度 | `[14,3230)` 一致，解析通过 |
| ⑥ | 票据签名区 64 字节 | 与原文件**逐字节相同** |
| ⑦ | 队号残留（明文 / 票据内 / 外层 JSON） | **均为 0** |

### 占位值

| 被替换字段 | 原值 | 占位值 | 长度 | 实测命中 |
| --- | --- | --- | --- | --- |
| `team_no`（外层信封头，以及票据内层 JSON） | 12 位参赛队号（为隐私不在此复现） | 12 个字符的占位值 | 12 → 12 | 6 份 `.jlog` 各 2 处 |
| `device_digest`（票据内层，设备指纹） | 64 位十六进制 | 64 个 `0` | 64 → 64 | 6 份 `.jlog` 各 1 处 |
| `sealed_case_package_sha256`（票据内层） | 64 位十六进制 | 64 个 `0` | 64 → 64 | 6 份 `.jlog` 各 1 处 |
| `case_unlock_envelope_sha256`（票据内层） | 64 位十六进制 | 64 个 `0` | 64 → 64 | 6 份 `.jlog` 各 1 处 |
| `.result.json` 的 `team_no` | 12 位参赛队号（为隐私不在此复现） | 12 个字符的占位值 | 12 → 12 | 6 份 `.result.json` 各 1 处 |
