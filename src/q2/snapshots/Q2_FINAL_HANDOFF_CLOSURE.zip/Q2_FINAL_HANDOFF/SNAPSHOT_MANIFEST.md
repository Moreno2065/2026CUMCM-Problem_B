# Q2 final immutable snapshot — Gate G′ V3

snapshot_id = q2_final_pass_v11_20260911_094034
snapshot_created_at = 2026-09-11T09:40:34+08:00
gate_status = GATE_G_PRIME=PASS; MULTIPROCESS_BACKEND=ADOPTED; CLEAN_ROOM_HANDOFF=PASS; FINAL_ACCEPTANCE_V3=PASS
source_snapshot = q2_gate_g_pass_v1_20260911_054813
verification_report = q2/code/artifacts/q2_final_verification_report.json
evidence_config = q2/code/artifacts/q2_final_evidence_config.json
benchmark = q2/code/artifacts/q2_batch_benchmark.json
git = not used

## Changes in this snapshot

- Added Hero/adaptive-surface closure with authoritative re-evaluation and bounded promotion rounds.
- Added mirror-paired adaptive-cell refinement and point/area symmetry regressions.
- Fixed baseline numeric row positions; B1/B2 remain explicit infeasible markers and Hero is drawn at row index 3.
- Kept the serial evaluator as reference and the ProcessPool backend as an equivalent optional execution layer.
- Disabled path-sensitive Numba disk caching in the Q1 kernel so top-level and package imports are safe in the clean-room handoff.
- Excluded `__pycache__` from the handoff archive.

## Verification

Q2 = 145 passed, 1 skipped  
Q1 = 11 passed  
Ruff (Q2) = All checks passed  
Gate G′ production checks = 7 passed  
Clean-room ZIP = 1 passed in 525.23s

## Claim boundary

`CERTIFIED_GLOBAL_OPTIMUM = false`. Hero and eta candidate regions are deterministic numerical evidence; candidate regions are sampled non-proof sets. Gate H is not implemented.
